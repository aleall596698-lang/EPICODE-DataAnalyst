#creo il databese
CREATE DATABASE ToysGroup;
USE ToysGroup; 
SHOW TABLES;  
#creo le tabelle Category, Product, Sales, Country e Region 
CREATE TABLE Category (
  CategoryID INT AUTO_INCREMENT PRIMARY KEY,
  CategoryName VARCHAR(100) NOT NULL UNIQUE
  );
  CREATE TABLE Region (
  RegionID INT AUTO_INCREMENT PRIMARY KEY,
  RegionName VARCHAR(100) NOT NULL UNIQUE
);
CREATE TABLE Country (
CountryID INT AUTO_INCREMENT PRIMARY KEY,
CountryName VARCHAR(100) NOT NULL UNIQUE,
RegionID INT NOT NULL,
CONSTRAINT FK_Country_Region
FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);
CREATE TABLE Product (
  ProductID INT AUTO_INCREMENT PRIMARY KEY,
  CategoryID INT NOT NULL,
  ProductName VARCHAR(150) NOT NULL,
  PrezzoUnitario DECIMAL(10,2) NOT NULL CHECK (PrezzoUnitario > 0),
CONSTRAINT FK_Product_Category
FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);
CREATE TABLE Sales (
SalesID INT AUTO_INCREMENT PRIMARY KEY,
SaleDate DATE NOT NULL,
ProductID INT NOT NULL,
CountryID INT NOT NULL,
Quantity INT NOT NULL CHECK (Quantity > 0),
CONSTRAINT FK_Sales_Product FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
CONSTRAINT FK_Sales_Country FOREIGN KEY (CountryID) REFERENCES Country(CountryID)
);
#inserisco i dati nelle tabelle 
INSERT INTO Category (CategoryName) VALUES
('Action Figures'), ('Board Games'), ('Puzzles'),
('Dolls'), ('Vehicles'), ('STEM Kits'), ('Plush');
INSERT INTO Region (RegionName) VALUES
('West Europe'), ('South Europe'), ('North America');
INSERT INTO Country (CountryName, RegionID) VALUES
('Italy', (SELECT RegionID FROM Region WHERE RegionName='South Europe')),
('Spain', (SELECT RegionID FROM Region WHERE RegionName='South Europe')),
('France', (SELECT RegionID FROM Region WHERE RegionName='West Europe')),
('Germany', (SELECT RegionID FROM Region WHERE RegionName='West Europe')),
('United States', (SELECT RegionID FROM Region WHERE RegionName='North America')),
('Canada', (SELECT RegionID FROM Region WHERE RegionName='North America'));
INSERT INTO Product (CategoryID, ProductName, PrezzoUnitario) VALUES
((SELECT CategoryID FROM Category WHERE CategoryName='Action Figures'), 'Action Figure – Space Ranger', 24.90),
((SELECT CategoryID FROM Category WHERE CategoryName='Action Figures'), 'Action Figure – Mega Robot', 39.90),
((SELECT CategoryID FROM Category WHERE CategoryName='Board Games'), 'Board Game – Treasure Hunt', 29.90),
((SELECT CategoryID FROM Category WHERE CategoryName='Puzzles'), 'Puzzle 500 pcs – Ocean', 14.90),
((SELECT CategoryID FROM Category WHERE CategoryName='Dolls'), 'Doll – Classic', 25.00),
((SELECT CategoryID FROM Category WHERE CategoryName='Vehicles'), 'RC Car – Turbo', 59.90),
((SELECT CategoryID FROM Category WHERE CategoryName='STEM Kits'), 'STEM Kit – Robotics', 79.90),
((SELECT CategoryID FROM Category WHERE CategoryName='Plush'), 'Plush Bear – 30 cm', 19.90);
INSERT INTO Sales (SaleDate, ProductID, CountryID, Quantity) VALUES
('2023-11-18',
 (SELECT ProductID FROM Product WHERE ProductName='Action Figure – Space Ranger'),
 (SELECT CountryID FROM Country WHERE CountryName='Italy'), 4),
('2023-12-05',
 (SELECT ProductID FROM Product WHERE ProductName='Puzzle 500 pcs – Ocean'),
 (SELECT CountryID FROM Country WHERE CountryName='Germany'), 6),
('2024-02-11',
 (SELECT ProductID FROM Product WHERE ProductName='Board Game – Treasure Hunt'),
 (SELECT CountryID FROM Country WHERE CountryName='France'), 3),
('2024-06-21',
 (SELECT ProductID FROM Product WHERE ProductName='RC Car – Turbo'),
 (SELECT CountryID FROM Country WHERE CountryName='Spain'), 2),
('2024-11-03',
 (SELECT ProductID FROM Product WHERE ProductName='Action Figure – Mega Robot'),
 (SELECT CountryID FROM Country WHERE CountryName='Italy'), 5),
('2025-03-19',
 (SELECT ProductID FROM Product WHERE ProductName='Doll – Classic'),
 (SELECT CountryID FROM Country WHERE CountryName='Italy'), 7),
('2025-05-10',
 (SELECT ProductID FROM Product WHERE ProductName='STEM Kit – Robotics'),
 (SELECT CountryID FROM Country WHERE CountryName='United States'), 3),
('2025-07-22',
 (SELECT ProductID FROM Product WHERE ProductName='RC Car – Turbo'),
 (SELECT CountryID FROM Country WHERE CountryName='Germany'), 4),
('2025-09-14',
 (SELECT ProductID FROM Product WHERE ProductName='Action Figure – Space Ranger'),
 (SELECT CountryID FROM Country WHERE CountryName='Canada'), 5);
 #Verifico che i campi definiti come PK siano univoci
SELECT ProductID, COUNT(*) AS cnt FROM Product GROUP BY ProductID HAVING COUNT(*) > 1;
SELECT CategoryID, COUNT(*) AS cnt FROM Category GROUP BY CategoryID HAVING COUNT(*) > 1;
SELECT RegionID, COUNT(*) AS cnt FROM Region GROUP BY RegionID HAVING COUNT(*) > 1;
SELECT CountryID, COUNT(*) AS cnt FROM Country GROUP BY CountryID HAVING COUNT(*) > 1;
SELECT SalesID, COUNT(*) AS cnt FROM Sales GROUP BY SalesID HAVING COUNT(*) > 1;
#espongo l'elenco delle transazioni completo più un campo booleano con la condizione che siano passati o meno 180 giorni dalla vendita
SELECT
s.SalesID,
s.SaleDate,
p.ProductName,
c.CategoryName,
co.CountryName,
r.RegionName,
CASE WHEN DATEDIFF(CURDATE(), s.SaleDate) > 180 THEN 1 ELSE 0 END AS IsOlderThan180Days
FROM Sales s
JOIN Product p ON p.ProductID = s.ProductID
JOIN Category c ON c.CategoryID = p.CategoryID
JOIN Country co ON co.CountryID = s.CountryID
JOIN Region r ON r.RegionID = co.RegionID
ORDER BY s.SaleDate;
#Espongo l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
WITH last_year AS (
SELECT MAX(YEAR(SaleDate)) AS y FROM Sales
),
tot_by_prod_last_year AS (
SELECT s.ProductID, SUM(s.Quantity) AS qty_last_year
FROM Sales s
JOIN last_year ly ON YEAR(s.SaleDate) = ly.y
GROUP BY s.ProductID
),
avg_last_year AS (
SELECT AVG(qty_last_year) AS avg_qty FROM tot_by_prod_last_year
),
tot_all_time AS (
SELECT ProductID, SUM(Quantity) AS qty_total
FROM Sales
GROUP BY ProductID
)
SELECT p.ProductName, t.qty_total
FROM tot_all_time t
JOIN Product p ON p.ProductID = t.ProductID
JOIN avg_last_year a
WHERE t.qty_total > a.avg_qty
ORDER BY t.qty_total DESC;
#Espongo l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
SELECT
p.ProductName,
YEAR(s.SaleDate) AS Year_,
SUM(s.Quantity * p.PrezzoUnitario) AS fatturatoannuo
FROM Sales s
JOIN Product p ON p.ProductID = s.ProductID
GROUP BY p.ProductName, YEAR(s.SaleDate)
ORDER BY p.ProductName, Year_;
#espongo il fatturato per paese per anno, ordinato per anno e fatturato decrescente
SELECT
co.CountryName,
YEAR(s.SaleDate) AS Year_,
SUM(s.Quantity * p.PrezzoUnitario) AS fatturatoannuo
FROM Sales s
JOIN Product p ON p.ProductID = s.ProductID
JOIN Country co ON co.CountryID = s.CountryID
GROUP BY co.CountryName, YEAR(s.SaleDate)
ORDER BY Year_, fatturatoannuo DESC;
#qual è la categoria di articoli maggiormente richiesta dal mercato? Action Figures
WITH qty_by_cat AS (
SELECT c.CategoryName, SUM(s.Quantity) AS TotalQty
FROM Sales s
JOIN Product p  ON p.ProductID  = s.ProductID
JOIN Category c ON c.CategoryID = p.CategoryID
GROUP BY c.CategoryName
),
ranked AS (
  SELECT CategoryName, TotalQty,
DENSE_RANK() OVER (ORDER BY TotalQty DESC) AS rnk
FROM qty_by_cat
)
SELECT CategoryName, TotalQty
FROM ranked
WHERE rnk = 1;
#quali sono i prodotti invenduti? Plush Bear - 30 cm 
#1° approccio
SELECT p.ProductName
FROM Product p
LEFT JOIN Sales s ON s.ProductID = p.ProductID
WHERE s.ProductID IS NULL;
#2° approccio
SELECT p.ProductName
FROM Product p
WHERE NOT EXISTS (SELECT 1 FROM Sales s WHERE s.ProductID = p.ProductID);
#creo una vista sui prodotti
CREATE VIEW v_product_denorm AS
(SELECT p.ProductID, p.ProductName, p.PrezzoUnitario, c.CategoryName
FROM Product p
JOIN Category c ON c.CategoryID = p.CategoryID);
#creo una vista per le informazioni geografiche
CREATE VIEW v_geo AS
SELECT co.CountryName, r.RegionName
FROM Country co
JOIN Region r ON r.RegionID = co.RegionID;
